<?php


function getServerList($sid)
{
    $serverList = [
        'game.dev.1' => ['gm_ip' => '127.0.0.1', 'gm_port' => 28082, 'name' => '1区'],
        'game.dev.2' => ['gm_ip' => '127.0.0.1', 'gm_port' => 28082, 'name' => '2区']
    ];
    return $serverList[$sid];
}