<?php

header("Access-Control-Allow-Origin:*"); // 跨域处理
header("Content-type: text/html; charset=utf-8");
error_reporting(0);
ini_set('date.timezone', 'Asia/Shanghai');
define('PAYDB', 'kdjx_pay');
define('DLDB', 'agency');
define('PAYTABLE', 't_pay');
define('DLTABLE', 'agency.amos_agency_pay');
define('DLUSTABLE', 'agency.amos_frame_user');
define('APPKEY', '3360df350a9dd978d3c5ac185c4e9f59');
//数据库连接
function linkMysql($db)
{
    define('MYSQLHOST', 'mysql:host=127.0.0.1;dbname=' . $db);
    define('MYSQLUSER', 'Nidzex');
    define('MYSQLPASS', '6bc0dd2a2b8e581c');
    $pdo = new PDO(MYSQLHOST, MYSQLUSER, MYSQLPASS) or die("数据库连接错误\n");
    $pdo->exec('set names utf8');
    return $pdo;
}

function postStr($str)
{
    if (isset($_POST[$str]) || !empty($_POST[$str])) {
        return $_POST[$str];
    }
    return false;
}

function getStr($str)
{
    if (isset($_GET[$str]) || !empty($_GET[$str])) {
        return $_GET[$str];
    }
    return false;
}

function outLog($msg)
{
    $dirname = dirname(__DIR__).'/log/';
    if (!is_dir($dirname)) {
        mkdir($dirname, 0777);
    }
    $date = date('Y-m-d');
    file_put_contents($dirname . 'pay.log', $msg . PHP_EOL, FILE_APPEND);
}

function outMsg($code, $msg = '', $data = [])
{
    $info = ['code' => $code, 'msg' => $msg, 'data' => $data];
    exit(json_encode($info, JSON_UNESCAPED_UNICODE));
}

function insterData($db, $table, $data)
{
    $pdo = linkMysql($db);
    $keys = join(',', array_keys($data));
    $values = "'" . join("','", array_values($data)) . "'";
    $sql = "INSERT INTO " . $table . " (" . $keys . ") VALUES (" . $values . ')';
    $result = $pdo->query($sql);
    return $result;
}

function updateData($db,$num,$acc)
{
    $pdo = linkMysql($db);
    
    $sql = "UPDATE `agency`.`amos_frame_user` SET `monery` = monery+'$num' WHERE `account` = '$acc'";
    
    $result = $pdo->query($sql);
    return $result;
}

function selectData($db, $file = '*', $table, $where = '', $limit = '')
{
    $pdo = linkMysql($db);
    $tables = $table;
    $sql = "SELECT {$file} FROM {$tables} WHERE {$where}";
    if (!empty($limit)) {
        $sql = "SELECT {$file} FROM {$tables} WHERE {$where} {$limit}";
    }
    
    $result = $pdo->query($sql);
    return $result;
}

function http_post($url, $data)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('User-Agent:Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36'));
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    $sResult = curl_exec($ch);
    if ($sError = curl_error($ch)) {
        die($sError);
    }
    curl_close($ch);
    $ret = json_decode($sResult, 1);
    $ret = $ret['ret'] == 0 ? 1 : 0;
    return $ret;
}