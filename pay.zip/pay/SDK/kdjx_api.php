<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirecting, please wait...</title>
    <style type="text/css">
        body {
            margin: 0;
            padding: 0
        }
        p {
            position: absolute;
            left: 50%;
            top: 50%;
            height: 35px;
            margin: -35px 0 0 -160px;
            padding: 20px;
            font: bold 16px/30px "宋体", Arial;
            text-indent: 40px;
            border: 1px solid #c5d0dc
        }
        #waiting {
            font-family: Arial
        }
    </style>
</head>
<body>
<?php
require_once("lib/epay.config.php");
require_once("lib/EpayCore.class.php");
require '../config/init.php';



/**************************请求参数**************************/
//商户订单号
$out_trade_no = $_POST['orderId'];
//支付方式（可传入alipay,wxpay,qqpay,bank,jdpay）
$type = $_POST['type'];
//商品名称
$name = $_POST['payName'];
//付款金额
$money = $_POST['money'];
//支付账号
$accountId = $_POST['accountId'];
$account = $_POST['account'];

if ($account == "") {
    exit("<script>alert('账号不可为空!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>");
}

//拼接原样返回参数
$param = $accountId . '_' . $out_trade_no. '_' . $account;

if ($type == 'djq') {
    $where2 = "account ='{$account}'";
    $result2 = selectData(PAYDB, '*', DLUSTABLE, $where2);
    $data2 = $result2->fetch();
    $djq = $data2['monery'];
    
    if ($djq == "") {
       $djq = 0;
    }
    
    if ($djq < $money) {
        exit("<script>alert('Contact Admin for balance!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>");
    }
    
    ?>
    <!doctype html>
    <html>
    <head>
    <title>Redirecting to payment page</title>
    </head>
    <body onload="document.pay.submit()">
        <form name="pay" action="kdjx_DjqCallBack.php" method="get">
            <input type="hidden" name="param" value="<?php echo $param?>">
        </form>
    </body>
    </html>
    <?php
    die();
}

/************************************************************/
// Get configurations
$epay_config = getPayConf();

// Initialize both payment systems
$epay = new EpayCore($epay_config);

// Your existing code to get payment details
$out_trade_no = $_POST['orderId'];
$type = $_POST['type'];
$name = $_POST['payName'];
$money = $_POST['money'];
$accountId = $_POST['accountId'];
$account = $_POST['account'];

if ($account == "") {
    exit("<script>alert('账号不可为空!');location.href='".$_SERVER["HTTP_REFERER"]."';</script>");
}

$param = $accountId . '_' . $out_trade_no. '_' . $account;


// Proceed with your existing Epay payment flow
$parameter = array(
    'pid' => $epay_config['pid'],
    'type' => $type,
    'notify_url' => $epay_config['notify_url'],
    'return_url' => $epay_config['return_url'],
    'out_trade_no' => $out_trade_no,
    'name' => $name,
    'money' => $money,
    'param' => $param
);

$html_text = $epay->pagePay($parameter);
echo $html_text;
?>
</body>
</html>