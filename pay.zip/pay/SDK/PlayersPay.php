<?php
/************** PlayersPay ************
require 'PlayersPay.php';
$PlayersPay = new \PlayersPay\PlayersPay();
$players_pay_data = [
    'account' => $account,   // 充值账户
    'money' => $yuanbao,     // 充值元宝
    'rmb' => 0,              // 充值人民币
    'serverid' => $serverid, // 服务器id
    'actorid' => $actorid ,  // 游戏中角色id
    'user_id' => 0,          // 代理id
];
$PlayersPay->AddPlayersPay($players_pay_data);
//************** PlayersPay ************ */
namespace PlayersPay;

define('AgencyPayUrl','http://106.55.158.130:84/frame_admin_api/pay/add_pay');
define('GUID','4b0462fe-0909-7baa-b8cd-2ffe71927cc1');

/*
 * agency_pay
 * */
class PlayersPay {

    /* */
    public function __construct() {
        // 校验服务器是否正常
        // return '代理服务器异常';
    }
    
    function AddPlayersPay(Array $data){
        // 补充
        $data['json'] = json_encode($_REQUEST);
        $data['pay_game_type'] = 2; // 充值游戏 2 雷霆传奇,3 幽冥传奇
        $data['timestamp'] = time();
        // 签名
        $sing = $this->get_sign($data); 
        $data['sing'] = $sing;
        // 提交
        $return_data = $this->CurlPost(AgencyPayUrl, $data);
        $return_data = json_decode($return_data, true);
        /*echo '<pre>';
        print_r($data);
        print_r($return_data);
        die;*/
        if(isset($return_data['type']) && $return_data['type'] == false) {
            // 
            $path = 'players_pay_error_log';
            if (!file_exists($path)) {
                dirname($path);
                mkdir($path, 0777);
            }
            $file = $path.'/' . date('Y-m-d-h-i', time()) .'_'.time().'_'. $data['account'] .'.txt';
            $myfile = fopen($file, "a+") or die("Unable to open file!");   // 打开文件 w 只写（覆盖） a只写（追加）
            // echo fgets($myfile); // 读取文件 
            fwrite($myfile, PHP_EOL.json_encode($data).PHP_EOL.json_encode($return_data));   // 写入文件
            fclose($myfile);         // 关闭文件
        }
    }
    
    /**
     * 签名通用算法，校验签名算法
     */
    function get_sign($params){
        ksort($params);
        reset($params);
        // 生成url的形式
        $url = http_build_query($params);
        // 生成sign
        $sign = md5($url . GUID);
        return $sign;
    }

    function CurlPost($url, $data)
    {
        $data = json_encode($data);
        $headerArray = array("Content-type:application/json;charset='utf-8'", "Accept:application/json");
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headerArray);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
}
?>

