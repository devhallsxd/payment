<?php
require dirname(__DIR__) . '/config/init.php';
require dirname(__DIR__) . '/config/serverList.php';
require_once("lib/epay.config.php");
require_once("lib/EpayCore.class.php");



//支付方式
$type = $_GET['type'];
$param = $_GET['param'];

if ('TRADE_SUCCESS' == 'TRADE_SUCCESS') {
    //判断该笔订单是否在商户网站中已经做过处理
    //如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
    //如果有做过处理，不执行商户的业务程序
    if (!isset($_GET['param']) || empty($_GET['param'])) {
        exit("param error");
    }

    $params = explode('_', $param);
    $accountId = $params[0];
    $orderId = $params[1];
    $account = $params[2];

    $where = "accountId = '{$accountId}' AND orderId='{$orderId}'";
    $result = selectData(PAYDB, '*', PAYTABLE, $where);

    if ($result->rowCount() < 1) {
        exit("orderId exits");
    }

    $payInfos = $result->fetch();
    $csvid = $payInfos['csvID'];
    $yyid = $payInfos['yyID'];
    $rechargeid = $payInfos['rechargeId'];
    $amount = $payInfos['amount'];
    $uid = $payInfos['accountId'];
    $rid = $payInfos['roleId'];
    $sid = $payInfos['serverId'];
    
    $userName = $payInfos['userName'];
    $money = $payInfos['money'];

    $loginfo = [
        'accountId' => $uid,
        'roleId' => $rid,
        'serverId' => $sid,
        'amount' => $amount,
        'rechargeId' => $rechargeid,
        'yyID' => $yyid,
        'csvID' => $csvid
    ];
    outLog('充值回调:' . json_encode($loginfo, JSON_UNESCAPED_UNICODE));

    $clientinfo = [$uid, $rid, $sid, $rechargeid, $yyid, $csvid];
    $data = [
        'accountId' => $uid,
        'orderStatus' => 1,
        'orderId' => time() . rand(1000, 9999),
        'amount' => $amount
    ];

    $signstr = '';
    foreach ($data as $k => $v) {
        $signstr .= $k . '=' . $v . '&';
    }
    $data['game_extra'] = json_encode($clientinfo);
    $signstr .= 'game_extra=' . urlencode($data['game_extra']) . '&secret_key=' . APPKEY;
    $data['sign'] = sha1($signstr);

    $serverInfo = getServerList($sid);
    $gmip = $serverInfo['gm_ip'];
    $gmport = $serverInfo['gm_port'];
    $payurl = 'http://' . $gmip . ':' . $gmport . '/test/payment';

    $money = -$money;
    $result = updateData(DLDB, $money, $account);

    $ret = http_post($payurl, $data);
    if (!$ret) {
        exit("pay fail");
    }


    exit ("<script> alert('Payment successful');parent.location.href='return.php'; </script>");
}
