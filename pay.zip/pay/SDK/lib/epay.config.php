<?php
/* *
 * 配置文件
 */
function getPayConf()
{
	$baseUrl = 'http://37.114.50.111/SDK/kdjxCallBack.php';
    //$baseUrl = 'http://106.55.158.130:82/SDK';
    $conf = [
        'apiurl' => 'http://pay.wchunh.top/',//支付接口地址
        'pid' => '1001',//商户ID
        'key' => 'OSLAXyLsxA511F5xNS421EllC2ewazyl',//商户密钥
        'notify_url' => $baseUrl . '/kdjxCallBack.php',
        'return_url' => $baseUrl . '/return_url.php'
    ];
    return $conf;
}