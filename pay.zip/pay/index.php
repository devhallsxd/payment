<?php

echo 'hello world！';