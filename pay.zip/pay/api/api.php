<?php

/**
 * 创建订单API
 */
require dirname(__DIR__) . '/config/init.php';
$payDatas = postStr('payDatas');
outLog('创建订单:' . $payDatas);
$payinfos = json_decode($payDatas, 1);


//print_r($payinfos);die();
$account = $payinfos['account'];
$userName = $payinfos['userName'];
$svrName = $payinfos['svrName'];
$orderId = $payinfos['orderId'];
$amount = intval($payinfos['amount']);
$payName = $payinfos['payName'];
$accountId = $payinfos['accountId'];
$roleId = $payinfos['roleId'];
$serverId = $payinfos['serverId'];
$rechargeId = $payinfos['rechargeId'];
$yyID = $payinfos['yyID'];
$csvID = $payinfos['csvID'];


if ($rechargeId==3 ||$rechargeId==4 ||$rechargeId==5 ||$rechargeId==6 ||$rechargeId==7 ||$rechargeId==8 ||$rechargeId==9) {
   $money = $amount/100;
}
else{
$money = $amount / 10;
}

$where = "accountId = '{$accountId}' AND orderId='{$orderId}'";
$result = selectData(PAYDB, '*', PAYTABLE, $where);
if ($result->rowCount() > 0) {
    outMsg(-100, 'Order exits');
}
$data = [
    'accountId' => $accountId,
    'roleId' => $roleId,
    'orderId' => $orderId,
	'account' => $account,
    'userName' => $userName,
    'svrName' => $svrName,
    'money' => $money,
    'orderStatus' => 1,
    'amount' => $amount,
    'payName' => $payName,
    'serverId' => $serverId,
    'rechargeId' => $rechargeId,
    'yyID' => $yyID,
    'csvID' => $csvID,
    'payStatus' => 0
];
$result = insterData(PAYDB, PAYTABLE, $data);
if (!$result) {
    outMsg(-101, 'Create Order fail');
}
outMsg(0, 'Create Order OK');